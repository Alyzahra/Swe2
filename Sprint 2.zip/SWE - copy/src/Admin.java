import java.util.Scanner;

import test.Products;

import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Admin implements Products {
	
	private String brandname;
	private String brandcategory;
	private Controller obj;
	private User obj1;
		
public void addbrands() throws IOException {
	File f = new File("C:\\Users\\Aly Zahra\\Desktop\\Sprint 2\\New folder (3)\\SWE - copy" ,"AdminBrands");
	FileWriter h = new FileWriter(f, true);
	System.out.println("Enter Brand name");
	Scanner x = new Scanner(System.in);
	this.brandname= x.next();
	System.out.println("Enter Brand category");
	Scanner p = new Scanner(System.in);
	this.brandcategory = p.next();
	h.write(this.brandname);
	h.write("\n");
	h.write(this.brandcategory);
	h.write("\n");
	h.write("\\\\\\\\\\\\\\");
	System.out.println("Brand Is Added Successfuly");
	h.close();
	
}

public boolean approveStore(String w) throws IOException {
	Controller obj = new Controller();
	return obj.VerifyStore(w);
}

public boolean approveProduct(String i ) throws IOException {
	Controller obj = new Controller();
	return obj.VerifyProduct(i);
}

public void addProduct() throws IOException {
	// TODO Auto-generated method stub
	File f = new File("C:\\Users\\Aly Zahra\\Desktop\\Sprint 2\\New folder (3)\\SWE - copy" ,"AdminProducts.txt");
	FileWriter h = new FileWriter(f, true);
	System.out.println("Enter name");
	Scanner x = new Scanner(System.in);
	String z = x.next();
	System.out.println("Enter price");
	Scanner y = new Scanner(System.in);
	String w = y.next();
	System.out.println("Enter Brand");
	Scanner u = new Scanner(System.in);
	String i = u.next();
	System.out.println("Enter category");
	Scanner p = new Scanner(System.in);
	String o = p.next();
	h.write(z);
	h.write("\n");
	h.write(w);
	h.write("\n");
	h.write(i);
	h.write("\n");
	h.write(o);
	h.write("\n");
	System.out.println("Product Is Added Successfuly");
	h.close();		
}

public void Admin_login() throws IOException {
	User obj1 = new User();
	obj1.login();
}



/*public Products search(String name) throws FileNotFoundException, IOException{ 
    int count = 1;
Integer intInstance = new Integer(count);      
String numberAsString = intInstance.toString();
   BufferedReader reader=new BufferedReader(new FileReader("F:\\College\\Software Engineering 2 project code\\SWE - copy"));
   String row=reader.readLine();
   while(row!=null){ 
   String[] fields=row.split(" ");
   String CurrentProduct=fields[0];
   if(name.equals(CurrentProduct)){
    System.out.println(row);
   }
   row=reader.readLine();
   }
    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
LocalDateTime now = LocalDateTime.now(); 
   PrintWriter writer =new PrintWriter(new FileWriter("",true));
 String newRow=this.getName();
  newRow = newRow.concat(" ");
   newRow=newRow.concat(name);
   newRow = newRow.concat(" ");
   newRow=newRow.concat(dtf.format(now));
    newRow = newRow.concat(" ");
   newRow=newRow.concat(numberAsString);
   writer.println(newRow);
writer.close();
   return null;
}*/

}