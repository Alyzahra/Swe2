import java.io.IOException;
import java.util.Scanner;
import java.util.Timer;


public class Main{

public static void main(String[] args) throws IOException {
	  User x = new User();
	  Admin y = new Admin();
	  StoreOwner z = new StoreOwner();
	  
	  System.out.println("Welcome to 5od Fekra w Eshtery Bokra!"); 
	  System.out.println("New Account? Press 0 / Login? Press 1");
	  Scanner l = new Scanner(System.in);
	  int h = l.nextInt();
	switch(h)
	{ 
	case(0):{
		x.createaccount();
	}
	break;
	
	case(1):
	{
		System.out.println("Admin? Press 0 / User? Press 1 / StoreOwner? Press 2");
		Scanner k = new Scanner(System.in);
		  int o = k.nextInt();
		if(o == 0) {
			y.Admin_login();
			System.out.println("Want to Add Products? Press 0 / Want to Add Brands? Press 1");
			Scanner j = new Scanner(System.in);
			  int a = j.nextInt();
			  if(a==0) {
				  y.addProduct();
			  }
			  else if(a==1) {
				  y.addbrands();
			  }
			  else
				  System.out.println("Fawa2 ya3am el hag 2olna Press 0 aw 1");
		}
		else if(o == 1) {
			x.login();
		}
		else if(o == 2) {
			z.StoreOwner_login();
			System.out.println("Want to Add Products? Press 0 / Want to Add Store? Press 1 / Want to show views? Press 2");
			Scanner j = new Scanner(System.in);
			  int a = j.nextInt();
			  if(a==0) {
				  z.addProduct();
			  }
			  else if(a==1) {
				  z.addStore();
			  }
			  else if(a==2) {
				  z.getviews();
				 // Timer timer = new Timer();
				 // timer.schedule(new Controller(), 0, 500);
			  }
			  else
				  System.out.println("Ma saba7 el fool ba2a :D");
		}
		else
			System.out.println("3ayez eh delwa2ty!!");
	}
	break;
	
	}

    
	}

}