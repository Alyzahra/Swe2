import java.util.Scanner;
import java.io.*;
public class User {
	private String name;
	private String pass;
	private String email;
	private String username;
	private int phoneno;
	public String n ;
	public String p ;
	private Controller obj;
	
public String getName() {
		return name;
}
	
public void setName(String name) {
		this.name = name;
}
	
public String getPass() {
		return pass;
}
	
public String getEmail() {
		return email;
}
	
public void setEmail(String email) {
		this.email = email;
}
	
public String getUsername() {
		return username;
}
	
public int getPhoneno() {
		return phoneno;
}
	
public void setPhoneno(int phoneno) {
		this.phoneno = phoneno;
}
	
public void login() throws IOException {
		Scanner input1 = new Scanner(System.in);
		System.out.println("Enter Username : ");
		n = input1.next();
		Scanner input2 = new Scanner(System.in);
	    System.out.println("Enter Password : ");
	    p = input2.next();
	    Controller obj = new Controller();
		obj.verify(n,p );
}	
	    
public void createaccount() throws IOException{		
		File f = new File("C:\\Users\\Aly Zahra\\Desktop\\Sprint 2\\New folder (3)\\SWE - copy" ,"Users.txt");
		FileWriter h = new FileWriter(f, true);
		System.out.println("Enter name");
		Scanner x = new Scanner(System.in);
		String z = x.next();
		System.out.println("Enter password");
		Scanner y = new Scanner(System.in);
		String w = y.next();
		System.out.println("Enter email");
		Scanner u = new Scanner(System.in);
		String i = u.next();
		System.out.println("Enter username");
		Scanner p = new Scanner(System.in);
		String o = p.next();
		System.out.println("Enter phoneno");
		Scanner k = new Scanner(System.in);
		int l = k.nextInt();
		this.name=z;
		this.pass=w;
		this.email=i;
		this.username=o;
		this.phoneno=l;
		h.write(o);
		h.write("\n");
		h.write(w);
		h.write("\n");
		System.out.println("Account Created Successfuly");
		h.close();
}
	    	
}	