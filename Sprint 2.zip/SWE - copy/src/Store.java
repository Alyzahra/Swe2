
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;


public class Store {

	private String storeName;
	private String storeType;
	private String storeAddress;
	private Admin obj2;
	
public String getStoreType() {
		return storeType;
	}

public void setStoreType(String storeType) {
		this.storeType = storeType;
	}

public String getStoreName() {
		return storeName;
	}
	
public void setStoreName(String storeName) {
		this.storeName = storeName;
	}
	
public String getStoreAddress() {
		return storeAddress;
	}
	
public void setStoreAddress(String storeAddress) {
		this.storeAddress = storeAddress;
	}
		
public void IsOnline() throws IOException {	
		File f = new File("C:\\Users\\Aly Zahra\\Desktop\\Sprint 2\\New folder (3)\\SWE - copy" ,"Store.txt");
		FileWriter h = new FileWriter(f, true);
	    System.out.println("Online? if yes press 1");
		Scanner x = new Scanner(System.in);
		int z = x.nextInt();
		if(z==1) {
			System.out.println("Enter store name");
			Scanner y = new Scanner(System.in);
			String l = y.next();
			System.out.println("Enter store Type");
			Scanner q = new Scanner(System.in);
			String w = q.next();
			this.setStoreName(l);
			this.setStoreType(w);
			Admin obj2 = new Admin();
			obj2.approveStore(w);
			if(obj2.approveStore(w) == true) {
			h.write(l);
			h.write("\n");
			h.write(w);
			h.write("\n");
			System.out.println("Store Created!");
			h.close();
			}
			else 
				System.out.println("Store doesn't meet criteria!");
		}
		else {
			System.out.println("Enter store name");
			Scanner e = new Scanner(System.in);
			String n = e.next();
			System.out.println("Enter store Type");
			Scanner t = new Scanner(System.in);
			String g = t.next();
			System.out.println("Enter store address");
			Scanner u = new Scanner(System.in);
			String k = u.next();
			this.setStoreAddress(k);
			this.setStoreName(n);
			this.setStoreType(g);
			Admin obj2 = new Admin();
			obj2.approveStore(g);
			if(obj2.approveStore(g) == true) {
			h.write(n);
			h.write("\n");
			h.write(g);
			h.write("\n");
			h.write(k);
			h.write("\n");
			System.out.println("Store Created!");
			h.close();
			}
			else 
				System.out.println("Store doesn't meet criteria!");
		}
		
	}
		
}