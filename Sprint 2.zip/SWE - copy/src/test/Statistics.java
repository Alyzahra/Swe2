package test;

import java.io.FileNotFoundException;
import java.io.IOException;

public interface Statistics {
	public void getviews() throws FileNotFoundException, IOException;

}
