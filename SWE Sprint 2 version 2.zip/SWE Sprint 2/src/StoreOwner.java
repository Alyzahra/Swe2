
import java.util.Random;
import java.util.Scanner;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Handler;
import java.util.Random;

import test.Products;

import java.io.*;



public class StoreOwner  extends User   implements Products{

	private Store obj;
	private Admin obj1;	
	private Products1 obj2;

public void addStore() throws IOException {
	Store obj = new Store();
	obj.IsOnline();
}
	 
public void addProduct() throws IOException {
	// TODO Auto-generated method stub
	File f = new File("F:\\College\\Software Engineering 2 project code\\SWE Sprint 2" ,"StoreProducts.txt");
	FileWriter h = new FileWriter(f, true);
	Products1 obj2 = new Products1();
	System.out.println("Enter name");
	Scanner x = new Scanner(System.in);
	obj2.setName(x.next());
	System.out.println("Enter price");
	Scanner y = new Scanner(System.in);
	obj2.setPrice(y.next());
	System.out.println("Enter Brand");
	Scanner u = new Scanner(System.in);
	obj2.setBrand(u.next());
	System.out.println("Enter category");
	Scanner p = new Scanner(System.in);
	obj2.setCategory(p.next());
	Admin obj1 = new Admin();
	obj1.approveProduct(obj2.getBrand());
	h.write(obj2.getName());
	h.write("\n");
	h.write(obj2.getPrice());
	h.write("\n");
	h.write(obj2.getBrand());
	h.write("\n");
	h.write(obj2.getCategory());
	h.write("\n");
	System.out.println("Product Is Added Successfuly");
	h.close();		
}

public void StoreOwner_login() throws IOException {
	User obj3 = new User();
	obj3.login();
}

/*public void getviews() throws FileNotFoundException, IOException {
	int x = (int)(Math.random()*((15-9)+1))+9;
    System.out.println("Number of Store views : " + x);
    int s = (int)(Math.random()*((8-2)+1))+2;
    System.out.println("Number of user buy a store�s produce : " + s);
    int t = (int)(Math.random()*((7-6)+1))+6;
    System.out.println("Number of sold products in store : " + t);
}
		*/
}