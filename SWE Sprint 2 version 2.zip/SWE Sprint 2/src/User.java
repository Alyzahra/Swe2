import java.util.Scanner;
import java.io.*;
public class User {
	private String name;
	private String pass;
	private String email;
	private String username;
	private String phoneno;
	public String n ;
	public String p ;
	private Controller obj;
	
public String getName() {
		return name;
}
	
public void setName(String name) {
		this.name = name;
}

public void setPass(String pass) {
	this.pass = pass;
}

public String getPass() {
		return pass;
}
	
public String getEmail() {
		return email;
}
	
public void setEmail(String email) {
		this.email = email;
}
	
public void setUsername(String username) {
	this.username = username;
}

public String getUsername() {
		return username;
}
	
public String getPhoneno() {
		return phoneno;
}
	
public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
}

public void login() throws IOException {
		Scanner input1 = new Scanner(System.in);
		System.out.println("Enter Username : ");
		n = input1.next();
		Scanner input2 = new Scanner(System.in);
	    System.out.println("Enter Password : ");
	    p = input2.next();
	    Controller obj = new Controller();
		obj.verify(n,p );
}	
	    
public void createaccount() throws IOException{		
		File f = new File("F:\\College\\Software Engineering 2 project code\\SWE Sprint 2" ,"Users.txt");
		FileWriter h = new FileWriter(f, true);
		System.out.println("Enter name");
		Scanner x = new Scanner(System.in);
		this.setName(x.next());
		System.out.println("Enter password");
		Scanner y = new Scanner(System.in);
		this.setPass(y.next());
		System.out.println("Enter email");
		Scanner u = new Scanner(System.in);
		this.setEmail(u.next());
		System.out.println("Enter username");
		Scanner p = new Scanner(System.in);
		this.setUsername(p.next());
		System.out.println("Enter phoneno");
		Scanner k = new Scanner(System.in);
		this.setPhoneno(k.next());
		h.write(this.getUsername());
		h.write("\n");
		h.write(this.getPass());
		h.write("\n");
		System.out.println("Account Created Successfuly");
		h.close();
}

}	