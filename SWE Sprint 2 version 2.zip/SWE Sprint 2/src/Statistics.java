import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.TimerTask;

public class Statistics {
	int products_views ;
	int stores_view;
	int sold_products;
	int orderd_brand;
	

public int getOrderd_brand() {
		return orderd_brand;
	}
public void setOrderd_brand(int orderd_brand) {
		this.orderd_brand = orderd_brand;
	}
public int getProducts_views() {
		return products_views;
	}
public void setProducts_views(int products_views) {
		this.products_views = 0;
	}
public int getStores_view() {
		return stores_view;
	}
public void setStores_view(int stores_view) {
		this.stores_view = 0;
	}
public int getSold_products() {
		return sold_products;
	}
public void setSold_products(int sold_products) {
		this.sold_products = 0;
	}
	
}
